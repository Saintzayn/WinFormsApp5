﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RollandKnow
{
    public partial class signup : Form
    {
        public signup()
        {
            InitializeComponent();
        }

        private void buttonsignup_Click(object sender, EventArgs e)
        {
            string newUser = textBoxname.Text;
            string newPass = textBoxpassword.Text;


            if (string.IsNullOrWhiteSpace(newUser) || string.IsNullOrWhiteSpace(newPass))
            {
                MessageBox.Show("Lütfen kullanıcı adı ve şifreyi giriniz!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            bool exists = UserDatabase.Users.Any(u => u.username.Equals(newUser, StringComparison.OrdinalIgnoreCase));

            if (exists)
            {
                MessageBox.Show("Bu kullanıcı adı zaten kayıtlı!", "Kayıt Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            User kullanici = new User { username = newUser, password = newPass };



            UserDatabase.AddUser(kullanici);

            MessageBox.Show("Kayıt işlemi başarıyla tamamlandı!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Close();
        }

        private void buttoncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

     
    }
}