﻿using System;
using System.Linq;
using System.Windows.Forms;
using RollandKnow;


namespace RollandKnow
{
    public partial class signupandlogin : Form
    {
        public signupandlogin()
        {

            InitializeComponent();
        }

        private void buttonlogin_Click(object sender, EventArgs e)
        {
            string user = textBoxpassword1.Text;
            string pass = textBoxname1.Text;


            var found = UserDatabase.Users
                .FirstOrDefault(u => u.username == user && u.password == pass);

            if (found != null)
            {
                MessageBox.Show("Giriş başarılı!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Anamenü ana = new Anamenü();
                ana.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Yanlış kullanıcı adı veya şifre!", "Giriş Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonsignup1_Click(object sender, EventArgs e)
        {
            signup signup = new signup();
            signup.ShowDialog();

        }

      
    }
}