﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms; 
using Newtonsoft.Json; 

namespace RollandKnow
{

    public class User
    {
        public string username { get; set; }
        public string password { get; set; }
       
    }

    public static class UserDatabase
    {
        
        public static List<User> Users = new List<User>();

     
        private static readonly string DataFilePath = "users.json";

      
        public static void LoadUsers()
        {
            if (File.Exists(DataFilePath))
            {
                try
                {
                    string json = File.ReadAllText(DataFilePath);
                    var loadedUsers = JsonConvert.DeserializeObject<List<User>>(json);

                    if (loadedUsers != null)
                    {
                        Users = loadedUsers;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Kullanıcı verileri yüklenirken bir hata oluştu: {ex.Message}", "Veri Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                Users = new List<User>();
            }
        }

       
        public static void SaveUsers()
        {
            try
            {
               
                string json = JsonConvert.SerializeObject(Users, Formatting.Indented);
               
                File.WriteAllText(DataFilePath, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Kullanıcı verileri kaydedilirken bir hata oluştu: {ex.Message}", "Veri Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

     
        public static void AddUser(User newUser)
        {
            Users.Add(newUser);
            SaveUsers(); 
        }
    }
}